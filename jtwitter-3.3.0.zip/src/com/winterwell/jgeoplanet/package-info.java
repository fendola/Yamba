/**
 * JGeoPlanet is a sister-project by Winterwell which provides clients
 * for the Yahoo & Google geo-coding services.
 * {@link winterwell.jtwitter.Twitter_Geo} also implements the same service.
 * <p>
 * The base interfaces of JGeoPlanet are stored here, so that JTwitter
 * avoids a dependency. 
 */
package com.winterwell.jgeoplanet;